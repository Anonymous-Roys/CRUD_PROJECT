<?php
$conn = mysqli_connect('localhost', 'root', '', 'crud', 3307);
if (!$conn){
    die('Could not connect to database');
}
?>